from pathlib import Path
import sqlite3
from datetime import datetime, date

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "library.db"

app = FastAPI(
    title="Library Management System API",
    version="2.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5175",
        "http://127.0.0.1:5175",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class BookCreate(BaseModel):
    title: str
    author: str
    category: str


class IssueRequest(BaseModel):
    borrower_name: str
    due_date: date | None = None


def get_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def initialize_database():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                category TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Available'
            )
        """)

        columns = {
            row["name"]
            for row in db.execute("PRAGMA table_info(books)").fetchall()
        }

        if "borrower_name" not in columns:
            db.execute("ALTER TABLE books ADD COLUMN borrower_name TEXT")

        if "issue_date" not in columns:
            db.execute("ALTER TABLE books ADD COLUMN issue_date TEXT")

        if "due_date" not in columns:
            db.execute("ALTER TABLE books ADD COLUMN due_date TEXT")

        db.execute("""
            CREATE TABLE IF NOT EXISTS borrowing_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER,
                book_title TEXT NOT NULL,
                borrower_name TEXT NOT NULL,
                issue_date TEXT NOT NULL,
                due_date TEXT,
                returned_at TEXT,
                status TEXT NOT NULL DEFAULT 'Issued'
            )
        """)

        db.commit()


initialize_database()


def get_book_or_404(db, book_id):
    book = db.execute(
        "SELECT * FROM books WHERE id = ?",
        (book_id,),
    ).fetchone()

    if book is None:
        raise HTTPException(status_code=404, detail="Book not found")

    return book


@app.get("/")
def home():
    return {"message": "Library Management System API is running"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/books")
def get_books(search: str = ""):
    with get_db() as db:
        if search.strip():
            term = f"%{search.strip()}%"
            rows = db.execute(
                """
                SELECT id, title, author, category, status,
                       borrower_name, issue_date, due_date
                FROM books
                WHERE title LIKE ?
                   OR author LIKE ?
                   OR category LIKE ?
                   OR borrower_name LIKE ?
                ORDER BY id DESC
                """,
                (term, term, term, term),
            ).fetchall()
        else:
            rows = db.execute(
                """
                SELECT id, title, author, category, status,
                       borrower_name, issue_date, due_date
                FROM books
                ORDER BY id DESC
                """
            ).fetchall()

        return [dict(row) for row in rows]


@app.get("/stats")
def get_stats():
    with get_db() as db:
        total = db.execute(
            "SELECT COUNT(*) FROM books"
        ).fetchone()[0]

        available = db.execute(
            "SELECT COUNT(*) FROM books WHERE status = 'Available'"
        ).fetchone()[0]

        issued = db.execute(
            "SELECT COUNT(*) FROM books WHERE status = 'Issued'"
        ).fetchone()[0]

        categories = db.execute(
            "SELECT COUNT(DISTINCT category) FROM books"
        ).fetchone()[0]

        overdue = db.execute(
            """
            SELECT COUNT(*) FROM books
            WHERE status = 'Issued'
              AND due_date IS NOT NULL
              AND due_date < ?
            """,
            (date.today().isoformat(),),
        ).fetchone()[0]

        return {
            "total_books": total,
            "available_books": available,
            "issued_books": issued,
            "categories": categories,
            "overdue_books": overdue,
        }


@app.get("/history")
def get_history():
    with get_db() as db:
        rows = db.execute(
            """
            SELECT id, book_id, book_title, borrower_name,
                   issue_date, due_date, returned_at, status
            FROM borrowing_history
            ORDER BY id DESC
            """
        ).fetchall()

        return [dict(row) for row in rows]


@app.post("/books", status_code=201)
def add_book(book: BookCreate):
    title = book.title.strip()
    author = book.author.strip()
    category = book.category.strip()

    if not title or not author or not category:
        raise HTTPException(
            status_code=422,
            detail="Title, author and category are required",
        )

    with get_db() as db:
        cursor = db.execute(
            """
            INSERT INTO books (title, author, category, status)
            VALUES (?, ?, ?, 'Available')
            """,
            (title, author, category),
        )

        row = db.execute(
            "SELECT * FROM books WHERE id = ?",
            (cursor.lastrowid,),
        ).fetchone()

        db.commit()
        return dict(row)


@app.post("/books/{book_id}/issue")
def issue_book(book_id: int, request: IssueRequest):
    borrower = request.borrower_name.strip()

    if not borrower:
        raise HTTPException(
            status_code=422,
            detail="Borrower name is required",
        )

    due = request.due_date.isoformat() if request.due_date else None

    if due and request.due_date < date.today():
        raise HTTPException(
            status_code=422,
            detail="Due date cannot be in the past",
        )

    with get_db() as db:
        book = get_book_or_404(db, book_id)

        if book["status"] == "Issued":
            raise HTTPException(
                status_code=409,
                detail="This book is already issued",
            )

        issued_at = datetime.now().isoformat(timespec="seconds")

        db.execute(
            """
            UPDATE books
            SET status = 'Issued',
                borrower_name = ?,
                issue_date = ?,
                due_date = ?
            WHERE id = ?
            """,
            (borrower, issued_at, due, book_id),
        )

        db.execute(
            """
            INSERT INTO borrowing_history (
                book_id, book_title, borrower_name,
                issue_date, due_date, returned_at, status
            )
            VALUES (?, ?, ?, ?, ?, NULL, 'Issued')
            """,
            (book_id, book["title"], borrower, issued_at, due),
        )

        row = db.execute(
            "SELECT * FROM books WHERE id = ?",
            (book_id,),
        ).fetchone()

        db.commit()
        return dict(row)


@app.post("/books/{book_id}/return")
def return_book(book_id: int):
    with get_db() as db:
        book = get_book_or_404(db, book_id)

        if book["status"] != "Issued":
            raise HTTPException(
                status_code=409,
                detail="This book is not currently issued",
            )

        returned_at = datetime.now().isoformat(timespec="seconds")

        # Complete the latest matching open borrowing record.
        history = db.execute(
            """
            SELECT id FROM borrowing_history
            WHERE book_id = ?
              AND returned_at IS NULL
            ORDER BY id DESC LIMIT 1
            """,
            (book_id,),
        ).fetchone()

        if history:
            db.execute(
                """
                UPDATE borrowing_history
                SET returned_at = ?, status = 'Returned'
                WHERE id = ?
                """,
                (returned_at, history["id"]),
            )
        elif book["borrower_name"]:
            # Preserve history for a book issued before history was added.
            db.execute(
                """
                INSERT INTO borrowing_history (
                    book_id, book_title, borrower_name,
                    issue_date, due_date, returned_at, status
                )
                VALUES (?, ?, ?, ?, ?, ?, 'Returned')
                """,
                (
                    book_id,
                    book["title"],
                    book["borrower_name"],
                    book["issue_date"] or returned_at,
                    book["due_date"],
                    returned_at,
                ),
            )

        db.execute(
            """
            UPDATE books
            SET status = 'Available',
                borrower_name = NULL,
                issue_date = NULL,
                due_date = NULL
            WHERE id = ?
            """,
            (book_id,),
        )

        row = db.execute(
            "SELECT * FROM books WHERE id = ?",
            (book_id,),
        ).fetchone()

        db.commit()
        return dict(row)


@app.delete("/books/{book_id}")
def delete_book(book_id: int):
    with get_db() as db:
        book = get_book_or_404(db, book_id)

        if book["status"] == "Issued":
            raise HTTPException(
                status_code=409,
                detail="Return this book before deleting it",
            )

        db.execute("DELETE FROM books WHERE id = ?", (book_id,))
        db.commit()

        return {
            "message": "Book deleted successfully",
            "id": book_id,
        }