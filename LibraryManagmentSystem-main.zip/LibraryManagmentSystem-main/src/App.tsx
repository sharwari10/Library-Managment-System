import { useEffect, useMemo, useState } from 'react'
import './App.css'

const API_URL = 'http://127.0.0.1:8000'

type Book = {
  id: number
  title: string
  author: string
  category: string
  status: 'Available' | 'Issued'
  borrower_name?: string | null
  issue_date?: string | null
  due_date?: string | null
}

type HistoryRecord = {
  id: number
  book_id: number
  book_title: string
  borrower_name: string
  issue_date: string
  due_date?: string | null
  returned_at?: string | null
  status: string
}

function App() {
  const [books, setBooks] = useState<Book[]>([])
  const [history, setHistory] = useState<HistoryRecord[]>([])
  const [search, setSearch] = useState('')
  const [active, setActive] = useState('Dashboard')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [saving, setSaving] = useState(false)

  const [title, setTitle] = useState('')
  const [author, setAuthor] = useState('')
  const [category, setCategory] = useState('Programming')

  async function getErrorMessage(response: Response) {
    try {
      const data = await response.json()
      return data.detail || `Server error: ${response.status}`
    } catch {
      return `Server error: ${response.status}`
    }
  }

  async function loadBooks() {
    setLoading(true)
    setError('')

    try {
      const response = await fetch(`${API_URL}/books`)

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      const data: Book[] = await response.json()

      if (!Array.isArray(data)) {
        throw new Error('Backend did not return a list of books.')
      }

      setBooks(data)
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Could not connect to the backend.'
      )
    } finally {
      setLoading(false)
    }
  }

  async function loadHistory() {
    try {
      const response = await fetch(`${API_URL}/history`)

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      const data: HistoryRecord[] = await response.json()
      setHistory(Array.isArray(data) ? data : [])
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Could not load borrowing history.'
      )
    }
  }

  useEffect(() => {
    void loadBooks()
    void loadHistory()
  }, [])

  const filteredBooks = useMemo(() => {
    const query = search.trim().toLowerCase()

    return books.filter((book) =>
      `${book.title} ${book.author} ${book.category} ${
        book.borrower_name || ''
      } ${book.status} ${book.due_date || ''}`
        .toLowerCase()
        .includes(query)
    )
  }, [books, search])

  const filteredHistory = useMemo(() => {
    const query = search.trim().toLowerCase()

    return history.filter((item) =>
      `${item.book_title} ${item.borrower_name} ${item.status} ${
        item.issue_date || ''
      } ${item.due_date || ''}`
        .toLowerCase()
        .includes(query)
    )
  }, [history, search])

  const availableCount = books.filter(
    (book) => book.status === 'Available'
  ).length

  const issuedCount = books.filter(
    (book) => book.status === 'Issued'
  ).length

  const categoryCount = new Set(books.map((book) => book.category)).size

  const overdueCount = books.filter(
    (book) =>
      book.status === 'Issued' &&
      book.due_date &&
      book.due_date < new Date().toLocaleDateString('en-CA')
  ).length

  async function addBook(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSaving(true)
    setError('')
    setNotice('')

    try {
      const response = await fetch(`${API_URL}/books`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim(),
          author: author.trim(),
          category: category.trim(),
        }),
      })

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      await loadBooks()

      setTitle('')
      setAuthor('')
      setCategory('Programming')
      setShowForm(false)
      setActive('Books')
      setNotice('Book added successfully!')
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Could not add the book.'
      )
    } finally {
      setSaving(false)
    }
  }

  async function issueBook(book: Book) {
    const borrowerName = window.prompt(
      `Enter the student name to issue "${book.title}":`
    )

    if (borrowerName === null) return

    if (!borrowerName.trim()) {
      setError('Please enter the student name.')
      return
    }

    const dueDate = window.prompt(
      'Enter the due date (YYYY-MM-DD):'
    )

    if (dueDate === null) return

    const dateText = dueDate.trim()
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateText)

    if (!match) {
      setError('Enter the due date in YYYY-MM-DD format, e.g. 2026-10-20.')
      return
    }

    const year = Number(match[1])
    const month = Number(match[2])
    const day = Number(match[3])

    const parsedDate = new Date(Date.UTC(year, month - 1, day))

    if (
      parsedDate.getUTCFullYear() !== year ||
      parsedDate.getUTCMonth() !== month - 1 ||
      parsedDate.getUTCDate() !== day
    ) {
      setError('Please enter a valid calendar date.')
      return
    }

    const now = new Date()
    const today =
      `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`

    if (dateText < today) {
      setError('Due date cannot be in the past.')
      return
    }

    setError('')
    setNotice('')

    try {
      const response = await fetch(
        `${API_URL}/books/${book.id}/issue`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            borrower_name: borrowerName.trim(),
            due_date: dateText,
          }),
        }
      )

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      await loadBooks()
      await loadHistory()

      setNotice(
        `"${book.title}" issued to ${borrowerName.trim()}. Due date: ${dateText}.`
      )
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Could not issue the book.'
      )
    }
  }

  async function returnBook(book: Book) {
    const confirmed = window.confirm(
      `Return "${book.title}" from ${
        book.borrower_name || 'the borrower'
      }?`
    )

    if (!confirmed) return

    setError('')
    setNotice('')

    try {
      const response = await fetch(
        `${API_URL}/books/${book.id}/return`,
        { method: 'POST' }
      )

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      await loadBooks()
      await loadHistory()

      setNotice(`"${book.title}" returned successfully!`)
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Could not return the book.'
      )
    }
  }

  async function deleteBook(book: Book) {
    const confirmed = window.confirm(
      `Are you sure you want to delete "${book.title}"? This cannot be undone.`
    )

    if (!confirmed) return

    setError('')
    setNotice('')

    try {
      const response = await fetch(
        `${API_URL}/books/${book.id}`,
        { method: 'DELETE' }
      )

      if (!response.ok) {
        throw new Error(await getErrorMessage(response))
      }

      await loadBooks()
      await loadHistory()

      setNotice(`"${book.title}" deleted successfully.`)
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Could not delete the book.'
      )
    }
  }

  function isOverdue(book: Book) {
    if (book.status !== 'Issued' || !book.due_date) return false

    const now = new Date()
    const today =
      `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`

    return book.due_date.slice(0, 10) < today
  }

  function formatDate(value?: string | null) {
    if (!value) return '—'

    const parts = value.slice(0, 10).split('-')

    if (parts.length !== 3) return value

    return `${parts[2]}-${parts[1]}-${parts[0]}`
  }

  const navItems = [
    { name: 'Dashboard', icon: '▦' },
    { name: 'Books', icon: '▤' },
    { name: 'History', icon: '◷' },
  ]

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-logo">L</div>
          <div>
            <h2>Libra</h2>
            <p>LIBRARY MANAGEMENT</p>
          </div>
        </div>

        <p className="nav-heading">WORKSPACE</p>

        <nav className="nav-list">
          {navItems.map((item) => (
            <button
              key={item.name}
              className={`nav-item ${active === item.name ? 'active' : ''}`}
              onClick={() => {
                setActive(item.name)
                setSearch('')
                setError('')
                if (item.name === 'History') void loadHistory()
              }}
            >
              <span className="nav-icon">{item.icon}</span>
              {item.name}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="admin-avatar">A</div>
          <div>
            <strong>Admin</strong>
            <p>Library Administrator</p>
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div>
            <p className="eyebrow">LIBRARY MANAGEMENT / OVERVIEW</p>
            <h1>
              {active === 'Dashboard'
                ? 'Good morning, Admin 👋'
                : active === 'Books'
                  ? 'Book Catalogue'
                  : 'Borrowing History'}
            </h1>
            <p className="subtitle">
              {active === 'Dashboard'
                ? "Here's what's happening in your library today."
                : active === 'Books'
                  ? 'Browse and manage your library collection.'
                  : 'Review issued and returned books.'}
            </p>
          </div>

          {active !== 'History' && (
            <button
              className="primary-button"
              onClick={() => {
                setShowForm(true)
                setNotice('')
                setError('')
              }}
            >
              + Add Book
            </button>
          )}
        </header>

        {error && (
          <div className="alert error-alert">
            <span>{error}</span>
            <button onClick={() => setError('')}>×</button>
          </div>
        )}

        {notice && (
          <div className="alert success-alert">
            <span>{notice}</span>
            <button onClick={() => setNotice('')}>×</button>
          </div>
        )}

        {showForm && active !== 'History' && (
          <section className="form-card">
            <div className="section-heading">
              <div>
                <h2>Add a new book</h2>
                <p>Enter the book details below.</p>
              </div>

              <button
                className="close-button"
                onClick={() => setShowForm(false)}
                aria-label="Close form"
              >
                ×
              </button>
            </div>

            <form onSubmit={addBook} className="book-form">
              <label>
                Book title
                <input
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                  placeholder="e.g. Python Basics"
                  required
                />
              </label>

              <label>
                Author
                <input
                  value={author}
                  onChange={(event) => setAuthor(event.target.value)}
                  placeholder="e.g. John Smith"
                  required
                />
              </label>

              <label>
                Category
                <select
                  value={category}
                  onChange={(event) => setCategory(event.target.value)}
                >
                  <option>Programming</option>
                  <option>Computer Science</option>
                  <option>Self Help</option>
                  <option>Finance</option>
                  <option>Fiction</option>
                  <option>Education</option>
                  <option>Other</option>
                </select>
              </label>

              <div className="form-actions">
                <button
                  type="button"
                  className="secondary-button"
                  onClick={() => setShowForm(false)}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="primary-button"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Save Book'}
                </button>
              </div>
            </form>
          </section>
        )}

        {active === 'Dashboard' && (
          <>
            <section className="stats-grid">
              <div className="stat-card">
                <div className="stat-top">
                  <span>Total Books</span>
                  <span className="stat-icon blue">▤</span>
                </div>
                <strong>{loading ? '—' : books.length}</strong>
                <p>Books in your catalogue</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span>Available Books</span>
                  <span className="stat-icon green">✓</span>
                </div>
                <strong>{loading ? '—' : availableCount}</strong>
                <p>Ready to be borrowed</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span>Issued Books</span>
                  <span className="stat-icon orange">↗</span>
                </div>
                <strong>{loading ? '—' : issuedCount}</strong>
                <p>Currently issued</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span>Categories</span>
                  <span className="stat-icon purple">▦</span>
                </div>
                <strong>{loading ? '—' : categoryCount}</strong>
                <p>Different categories</p>
              </div>

              <div className="stat-card">
                <div className="stat-top">
                  <span>Overdue Books</span>
                  <span className="stat-icon purple">!</span>
                </div>
                <strong>{loading ? '—' : overdueCount}</strong>
                <p>Past their due date</p>
              </div>
            </section>

            <section className="catalogue-card">
              <div className="section-heading">
                <div>
                  <h2>Book Catalogue</h2>
                  <p>Books stored in your backend database.</p>
                </div>

                <button
                  className="secondary-button"
                  onClick={() => {
                    void loadBooks()
                    void loadHistory()
                  }}
                  disabled={loading}
                >
                  {loading ? 'Loading...' : '↻ Refresh'}
                </button>
              </div>

              <BookTable
                books={filteredBooks}
                loading={loading}
                search={search}
                setSearch={setSearch}
                onIssue={issueBook}
                onReturn={returnBook}
                onDelete={deleteBook}
                isOverdue={isOverdue}
                formatDate={formatDate}
              />
            </section>
          </>
        )}

        {active === 'Books' && (
          <section className="catalogue-card">
            <div className="section-heading">
              <div>
                <h2>All Books</h2>
                <p>{books.length} books in your collection.</p>
              </div>

              <button
                className="secondary-button"
                onClick={() => void loadBooks()}
                disabled={loading}
              >
                {loading ? 'Loading...' : '↻ Refresh'}
              </button>
            </div>

            <BookTable
              books={filteredBooks}
              loading={loading}
              search={search}
              setSearch={setSearch}
              onIssue={issueBook}
              onReturn={returnBook}
              onDelete={deleteBook}
              isOverdue={isOverdue}
              formatDate={formatDate}
            />
          </section>
        )}

        {active === 'History' && (
          <section className="catalogue-card">
            <div className="section-heading">
              <div>
                <h2>Borrowing History</h2>
                <p>{history.length} borrowing records.</p>
              </div>

              <button
                className="secondary-button"
                onClick={() => void loadHistory()}
              >
                ↻ Refresh
              </button>
            </div>

            <div className="table-toolbar">
              <input
                className="search-input"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by book or student..."
                aria-label="Search borrowing history"
              />

              <span className="result-count">
                {filteredHistory.length} result
                {filteredHistory.length === 1 ? '' : 's'}
              </span>
            </div>

            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>BOOK</th>
                    <th>STUDENT</th>
                    <th>ISSUE DATE</th>
                    <th>DUE DATE</th>
                    <th>RETURNED AT</th>
                    <th>STATUS</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredHistory.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="empty-state">
                        No borrowing history found.
                      </td>
                    </tr>
                  ) : (
                    filteredHistory.map((item) => (
                      <tr key={item.id}>
                        <td>{item.book_title}</td>
                        <td>{item.borrower_name}</td>
                        <td>{formatDate(item.issue_date)}</td>
                        <td>{formatDate(item.due_date)}</td>
                        <td>{formatDate(item.returned_at)}</td>
                        <td>
                          <span
                            className={`status-pill ${
                              item.returned_at ? 'available' : 'issued'
                            }`}
                          >
                            {item.returned_at ? 'Returned' : item.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>
        )}

        <footer className="footer">
          <span>Libra Library Management System</span>
          <span>Connected to FastAPI · SQLite</span>
        </footer>
      </main>
    </div>
  )
}

type BookTableProps = {
  books: Book[]
  loading: boolean
  search: string
  setSearch: (value: string) => void
  onIssue: (book: Book) => void
  onReturn: (book: Book) => void
  onDelete: (book: Book) => void
  isOverdue: (book: Book) => boolean
  formatDate: (value?: string | null) => string
}

function BookTable({
  books,
  loading,
  search,
  setSearch,
  onIssue,
  onReturn,
  onDelete,
  isOverdue,
  formatDate,
}: BookTableProps) {
  return (
    <>
      <div className="table-toolbar">
        <input
          className="search-input"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="⌕ Search by title, author, category or student..."
          aria-label="Search books"
        />

        <span className="result-count">
          {books.length} result{books.length === 1 ? '' : 's'}
        </span>
      </div>

      <div className="table-wrapper">
        <table>
          <thead>
            <tr>
              <th>BOOK TITLE</th>
              <th>AUTHOR</th>
              <th>CATEGORY</th>
              <th>STATUS</th>
              <th>BORROWER</th>
              <th>DUE DATE</th>
              <th>ID</th>
              <th>ACTIONS</th>
            </tr>
          </thead>

          <tbody>
            {loading ? (
              <tr>
                <td colSpan={8} className="empty-state">
                  Loading books from backend...
                </td>
              </tr>
            ) : books.length === 0 ? (
              <tr>
                <td colSpan={8} className="empty-state">
                  No books found. Try another search or add a book.
                </td>
              </tr>
            ) : (
              books.map((book) => (
                <tr key={book.id}>
                  <td>
                    <div className="book-title-cell">
                      <span className="book-avatar">
                        {book.title?.charAt(0)?.toUpperCase() || 'B'}
                      </span>
                      <strong>{book.title}</strong>
                    </div>
                  </td>

                  <td>{book.author}</td>

                  <td>
                    <span className="category-label">{book.category}</span>
                  </td>

                  <td>
                    <span
                      className={`status-pill ${
                        isOverdue(book)
                          ? 'overdue'
                          : book.status === 'Issued'
                            ? 'issued'
                            : 'available'
                      }`}
                    >
                      {isOverdue(book) ? 'Overdue' : book.status}
                    </span>
                  </td>

                  <td>
                    {book.status === 'Issued'
                      ? book.borrower_name || 'Unknown'
                      : '—'}
                  </td>

                  <td>{formatDate(book.due_date)}</td>

                  <td>#{book.id}</td>

                  <td>
                    <div className="action-buttons">
                      {book.status === 'Available' ? (
                        <button
                          className="primary-button action-button"
                          onClick={() => onIssue(book)}
                        >
                          Issue
                        </button>
                      ) : (
                        <button
                          className="secondary-button action-button"
                          onClick={() => onReturn(book)}
                        >
                          Return
                        </button>
                      )}

                      <button
                        className="secondary-button action-button delete-button"
                        disabled={book.status === 'Issued'}
                        title={
                          book.status === 'Issued'
                            ? 'Return the book before deleting it'
                            : 'Delete book'
                        }
                        onClick={() => onDelete(book)}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </>
  )
}

export default App